'use client'

import React, { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Trophy, Star, Heart } from 'lucide-react'

export default function Page() {
  const [currentLanguage, setCurrentLanguage] = useState('Spanish')
  const [score, setScore] = useState(0)
  const [lives, setLives] = useState(3)
  const [progress, setProgress] = useState(0)
  const [currentWord, setCurrentWord] = useState({ word: 'Hola', translation: 'Hello' })

  const languages = ['Spanish', 'French', 'German', 'Italian']
  const words = {
    Spanish: [
      { word: 'Hola', translation: 'Hello' },
      { word: 'Adiós', translation: 'Goodbye' },
      { word: 'Por favor', translation: 'Please' },
    ],
    French: [
      { word: 'Bonjour', translation: 'Hello' },
      { word: 'Au revoir', translation: 'Goodbye' },
      { word: 'S'il vous plaît', translation: 'Please' },
    ],
    German: [
      { word: 'Hallo', translation: 'Hello' },
      { word: 'Auf Wiedersehen', translation: 'Goodbye' },
      { word: 'Bitte', translation: 'Please' },
    ],
    Italian: [
      { word: 'Ciao', translation: 'Hello' },
      { word: 'Arrivederci', translation: 'Goodbye' },
      { word: 'Per favore', translation: 'Please' },
    ],
  }

  const handleAnswer = (isCorrect: boolean) => {
    if (isCorrect) {
      setScore(score + 10)
      setProgress(progress + 10)
      if (progress + 10 >= 100) {
        setProgress(0)
        setScore(score + 50) // bonus for completing a level
      }
    } else {
      setLives(lives - 1)
      if (lives - 1 <= 0) {
        alert('Game Over! Your score: ' + score)
        resetGame()
      }
    }
    nextWord()
  }

  const nextWord = () => {
    const newWord = words[currentLanguage][Math.floor(Math.random() * words[currentLanguage].length)]
    setCurrentWord(newWord)
  }

  const resetGame = () => {
    setScore(0)
    setLives(3)
    setProgress(0)
    nextWord()
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-[#3a86ff] p-4">
      <div className="w-full max-w-md bg-[#ffbe0b] p-6 rounded-lg shadow-lg" style={{imageRendering: 'pixelated'}}>
        <h1 className="text-4xl font-bold text-center mb-6 text-[#fb5607]" style={{fontFamily: "'Press Start 2P', cursive"}}>PixelLingo</h1>
        
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center">
            <Trophy className="w-6 h-6 mr-2 text-[#ff006e]" />
            <span className="font-bold text-[#ff006e]">{score}</span>
          </div>
          <div className="flex items-center">
            {[...Array(lives)].map((_, i) => (
              <Heart key={i} className="w-6 h-6 text-[#ff006e]" fill="#ff006e" />
            ))}
          </div>
        </div>

        <Progress value={progress} className="mb-4" />

        <div className="mb-4">
          <label className="block text-sm font-bold mb-2">Select Language:</label>
          <select
            value={currentLanguage}
            onChange={(e) => setCurrentLanguage(e.target.value)}
            className="w-full p-2 rounded bg-[#8338ec] text-white"
          >
            {languages.map((lang) => (
              <option key={lang} value={lang}>{lang}</option>
            ))}
          </select>
        </div>

        <div className="bg-[#3a86ff] p-4 rounded-lg mb-4">
          <h2 className="text-2xl font-bold text-center text-white mb-2">{currentWord.word}</h2>
          <p className="text-center text-white">What does this mean?</p>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          <Button onClick={() => handleAnswer(true)} className="bg-[#06d6a0] hover:bg-[#06d6a0]/80">
            {currentWord.translation}
          </Button>
          <Button onClick={() => handleAnswer(false)} className="bg-[#06d6a0] hover:bg-[#06d6a0]/80">
            Wrong Answer
          </Button>
        </div>

        <div className="text-center">
          <Button onClick={resetGame} className="bg-[#ff006e] hover:bg-[#ff006e]/80">
            Reset Game
          </Button>
        </div>
      </div>
    </div>
  )
}